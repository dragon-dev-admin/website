export const metadata = {
    id: 'token_info',
    sequence: 1,
    name: 'Token Info',
    description: 'Token identity, market cap, holder count, security checks, and platform links.',
    dataInputs: ['contractAddress', 'backendReport'],
    dataApis: ['uid/check', 'uid/set', 'fetchData', 'contract/check-update', 'coin-image'],
};

export async function mount({ root }) {
    root.innerHTML = `
      <div class="token-header" data-module-id="token_info">
        <div class="header-row">
          <div class="image-column">
            <div class="token-image-placeholder">
              <img id="tokenImage" src="images/dragon.png" alt="Token Icon" />
            </div>
          </div>

          <div class="name-column">
            <h3>Ticker</h3>
            <p id="tickerValue">Loading..</p>
            <div class="token-stats-grid">
              <div class="token-stat-item">
                <h4>Age</h4>
                <p id="tokenAge">Loading..</p>
              </div>
              <div class="token-stat-item">
                <h4>Holders</h4>
                <p class="holders-count" id="holdersCount">&gt;150</p>
              </div>
              <div class="token-stat-item">
                <div class="community-status">
                  <div class="community-icons">
                    <i class="fas fa-user"></i>
                  </div>
                  <span class="community-label">Dev</span>
                </div>
              </div>
            </div>
          </div>

          <div class="cap-column">
            <h3>Market Cap</h3>
            <p id="marketCap">Loading..</p>
            <div class="security-grid">
              <div class="security-item" id="mintStatus" title="Mint Authority Revoked">
                <i class="fas fa-check-circle success"></i>
                <span>Mint</span>
              </div>
              <div class="security-item" id="freezeStatus" title="Freeze Authority Revoked">
                <i class="fas fa-check-circle success"></i>
                <span>Freeze</span>
              </div>
              <div class="security-item" id="lockedStatus" title="Liquidity Pool Locked">
                <i class="fas fa-check-circle success"></i>
                <span>Locked</span>
              </div>
              <div class="security-item" id="dexStatus" title="DEX Screener Paid">
                <i class="fas fa-check-circle success"></i>
                <span>DEX</span>
              </div>
            </div>
          </div>
        </div>

        <div class="platform-links">
          <a href="#" class="platform-link inactive" title="Photon">
            <img src="images/1.png" alt="Photon Icon" style="width: 20px; height: 15px;">
          </a>
          <a href="https://pump.example.com" class="platform-link" title="pump.fun" target="_blank" rel="noopener noreferrer">
            <img src="images/Pump-Fun-Logo white.png" alt="Pump Icon" style="width: 28px; height: 15px;">
          </a>
          <a href="https://solscan.example.com" class="platform-link" title="Solscan" target="_blank" rel="noopener noreferrer">
            <img src="images/3.png" alt="Solscan Icon" style="width: 20px; height: 15px;">
          </a>
          <a href="#" class="platform-link" title="DEX Screener" target="_blank" rel="noopener noreferrer">
            <img src="images/2.png" alt="DexScreener Icon" style="width: 20px; height: 15px;">
          </a>
          <div class="platform-link-spacer"></div>
          <a href="#" class="platform-link" title="Website" target="_blank" rel="noopener noreferrer">
            <img src="images/website.png" alt="Website" style="width: 20px; height: 15px;">
          </a>
          <a href="https://twitter.com/example" class="platform-link" title="X" target="_blank" rel="noopener noreferrer">
            <img src="images/4.png" alt="Twitter Icon" style="width: 20px; height: 15px;">
          </a>
          <a href="#" class="platform-link" title="Telegram" target="_blank" rel="noopener noreferrer">
            <img src="images/tele.png" alt="Telegram" style="width: 20px; height: 15px;">
          </a>
        </div>
      </div>
    `;
}

export async function reset() {}
export async function load() {}
export async function destroy() {}
