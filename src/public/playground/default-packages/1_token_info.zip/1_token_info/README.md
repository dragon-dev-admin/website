# Token Info Module

Built-in module for token identity, market cap, age, holders, authority checks, and platform links.

This module renders DOM nodes consumed by the current side panel data pipeline. Keep IDs such as `tickerValue`, `tokenAge`, `holdersCount`, `marketCap`, `mintStatus`, `freezeStatus`, `lockedStatus`, `dexStatus`, and `tokenImage` stable unless the data adapter is updated too.
