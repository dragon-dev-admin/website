# Sniper Analysis Module

Built-in module for early-buyer and sniper visualization.

This module renders `timelineChart` and `.timeline-stats` nodes consumed by the current side panel data pipeline.
