export const metadata = {
    id: 'holder_analysis',
    sequence: 3,
    name: 'Holder Analysis',
    description: 'Cluster and top holder concentration charts.',
    dataInputs: ['contractAddress', 'backendReport'],
    dataApis: ['fetchData'],
};

export async function mount({ root }) {
    root.innerHTML = `
      <div class="sniper-section" data-module-id="holder_analysis">
        <div class="carousel-controls">
          <button id="prevBtn" class="nav-arrow" aria-label="Previous holder view"></button>
          <h4>Holder Analysis</h4>
          <button id="nextBtn" class="nav-arrow" aria-label="Next holder view"></button>
        </div>

        <div class="holders-analysis-carousel">
          <div class="analysis-view" id="clustersView">
            <div class="chart-box">
              <h5>Clusters</h5>
              <div class="chart-wrapper">
                <canvas id="clusterChart"></canvas>
              </div>
              <div class="chart-stat">Active Total: <strong>No Data</strong></div>
            </div>
          </div>

          <div class="analysis-view" id="topHoldersView">
            <div class="chart-box">
              <h5>Top 10 Holders</h5>
              <div class="chart-wrapper">
                <canvas id="holdersChart"></canvas>
              </div>
              <div class="chart-stat">
                Total: <strong id="totalHoldingsValue">No Data</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
}

export async function reset() {}
export async function load() {}
export async function destroy() {}
