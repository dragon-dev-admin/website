# Holder Analysis Module

Built-in module for cluster analysis and top holder concentration.

This module renders `clusterChart`, `holdersChart`, `totalHoldingsValue`, and holder carousel controls consumed by the current side panel data pipeline.
