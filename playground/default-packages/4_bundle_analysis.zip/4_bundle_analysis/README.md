# Bundle Analysis Module

Built-in module for coordinated supply and bundle charts.

This module renders `bundleDistMessage`, `.bundle-chart-container`, and `.bundle-stats` nodes consumed by the current side panel data pipeline.
